Todo: delete all unnecessary text, add suitable labels (with priotity and estimation), milestone, assignee
## Feature Template

### Related Issues/Tasks
- [ ] #1
- [ ] #2

### Scenario (test)
- [ ] Step 1
- [ ] ...
- [ ] Expected result

## User Stoty Template
- As a ...
- I want ...
- So that ...

## Bug Template
### Expected behavior
### Actual behavior
### Steps to reproduce the behavior

## Project Submission Template
Checklist, e.g.,:
- [ ] Test feature scenarios
- [ ] Update iteration page
  - [ ] Iteration retospective
  - [ ] Client review
  - [ ] Update issues
  - [ ] Application of course materials
- [ ] git tag
- [ ] Open page for next iteration 
  - [ ] Plan issues
- [ ] Submit (message in chat room, assign this issue to checker)
