(function(app){

    function homeController($scope) {
    }


    app.controller('homeController',homeController); // declare on the controller and run loginController


})( angular.module('diffSign'));


