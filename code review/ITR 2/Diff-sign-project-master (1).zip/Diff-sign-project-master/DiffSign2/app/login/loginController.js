(function(app){

    function loginController($scope) {
        $scope.message=' מסך זה עדיין בבניה...בונים פה כפרה :)';
    }


    app.controller('loginController',loginController); // declare on the controller and run loginController


})( angular.module('diffSign'));


